<footer class="main-footer">
    <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="https://paradisemodelschool.com.ng">Paradise Model School</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Developed by</b> <a target="_blank" href="https://www.google.com/search?q=doteightinc&oq=doteightinc&aqs=chrome..69i57j69i60j69i65j69i60l2.7521j0j7&sourceid=chrome&ie=UTF-8">DotEightInc.</a>
    </div>
  </footer>