<?php ob_start();



include("db.php");
include("functions.php");


if ($con) {
    
}
?>
